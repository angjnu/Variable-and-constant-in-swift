//
//  main.swift
//  HelloWordSwift
//
//  Created by anil kumar giri on 20/02/16.
//  Copyright © 2016 AKG. All rights reserved.
//

import Foundation

print("Hello, World!")
//declaring variable and printing 
var a=10     //declared as variable which can store integer
print(a)
let b=20    //declared as constant
print(b)
/*if you want to print a and b in string using print then follow this statement

*/
print("The value of a and b is \(a) and \(b) respectivly")

var x:Int=20
var y=10; var z=30
var p,q,r:Int
p=15
q=20
r=30
print("The value of x,y,p,q and r is \(x),\(y),\(z),\(p),\(q) and \(r) respectivly")


print(10,20,30,40,separator: "\n")